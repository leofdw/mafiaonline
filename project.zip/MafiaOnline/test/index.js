const socket = io();
//страницы
const pages = {
    main: `
        <div class="side-area side-left"></div>
        <div class="side-area side-right"></div>

        <div class="big-circle"></div>
        <div class="content">
            <h2 class="MTS">MTS</h2>
            <h1 class="Maf">Mafia True Story</h1>
            <div class="main_menu">
                <button class="connect_game" onclick="showPage('game')">Присоединиться к игре</button>
                <button class="create_game" onclick="showPage('lobby')">Создать лобби</button>
                <button class="avatar" onclick="showPage('avatar')">Изменить аватарку</button>
            </div>
        </div>
    `,
    
    game: `
        <div class="side-area side-left"></div>
        <div class="side-area side-right"></div>

        <div class="big-circle"></div>
        <div class="content">
            <h2 class="MTS">Присоединение к игре</h2>
            <div class="game-interface">
                
                <input class = "input" type="text" placeholder="Введите ID игры" maxlength="6"><br>
                <input class = "input" type = "text" placeholder="Введите никнэйм"><br>
                <div class = "main_menu">
                    <button id = "connect">Присоединиться</button><br>
                    <button onclick="showPage('main')">Назад</button>
                </div>
            </div>
        </div>
    `,
    
    load:`
        <div class="content">
            <div class = "main_menu">
                <h2 class="MTS">Создаём лобби....</h2>
            </div>
        </div>

    `,
    
    lobby: `
        <div class="side-area side-left"></div>
        <div class="side-area side-right"></div>

        <div class="big-circle"></div>
        <div class="content">
            <h2 class="MTS">Создание лобби</h2>
            <div class="lobby-interface">
                <h3>Выберите место, где будет происходить игра:</h3>
                <select name="game_place" id="game_place">
                    <option value="vodka">Унесённые водкой</option>
                    <option value="sifilis">Свинец, си***ис и легенда</option>
                    <option value="yebihe">Красавица и уё***е</option>
                </select><br><br>

                <input class = "input" id = "players_count" minlength="4" maxlength="14" placeholder="Введите количество игроков"><br>

                <select name="count_mafia" id="count_mafia"><br>
                    <option value="one_mafia">1 Мафия</option>
                    <option value="two_mafia">2 Мафии</option>
                    <option value="three_mafia">3 Мафии</option>
                </select><br>

                <input class = "checkbox" type="checkbox" id="kom" value="yes"><label for="kom">Комиссар может стрелять?</label><br>
                <input class = "checkbox" type="checkbox" id="prostitutka" value="yes"><label for="prostitutka">Проститутка есть в игре?</label><br><br><br>

                <div class = "main_menu">
                    <button onclick="">Создать лобби</button><br>
                    <button onclick="showPage('main')">Назад</button>
                </div>
            </div>
        </div>
    `,
    
    avatar: `
        <div class="side-area side-left"></div>
        <div class="side-area side-right"></div>

        <div class="big-circle"></div>
        <div class="content">
            <h2 class="MTS">Смена аватарки</h2>
            <div class="avatar-interface">
                <!-- Контент для смены аватарки -->
                <button onclick="showPage('main')">Назад</button>
            </div>
        </div>
    `,

    game_pool:`

    `
};
//подгрузка на экран
function showPage(pageName) {
    const contentContainer = document.getElementById('info');
    contentContainer.innerHTML = pages[pageName];
}
function loadExternalSite(url) {
    window.location.href = url;
}
//рандом мест в зависимости от количества игроков
function game_players(players){
    const game = document.getElementById("table");
    let player = [
        `<div class="player player-1">
            <div class="player-avatar" id = "player_avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,
        `<div class="player player-2">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-3">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-4">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-5">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-6">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-7">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-8">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-9">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-10">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-11">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-12">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-13">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-14">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-15">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-16">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-17">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-18">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-19">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-20">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div>
        </div>`,`<div class="player player-21">
            <div class="player-avatar" id = "player-avatar"></div>
            <div class="player-name" id = "player_name"></div></div>`
    ];
    let count = [0];
    for(let i = 0;i < players;i++){
        const random = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
        let place = random(1, 21);
        let flag = true;
        for(let i = 0;i < count.length;i++){
            if(count[i] == place){
                flag = false;
            }
        }
        if(flag){
            game.innerHTML += player[place];
            count.push(place);
        }
        else{
            i--;
        }
    }
}
//показ картинки
function showImage() {
    const image = document.getElementById('floatingImage');
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    document.body.appendChild(overlay);
    setTimeout(() => {
        image.classList.add('show');
        overlay.classList.add('show');
    }, 100);
    setTimeout(() => {
        image.classList.add('move-to-corner');
        overlay.classList.remove('show');

    }, 2000);


}
//картинки на каждую из ролей
function game_rule(rule){
    const game = document.getElementById('table');
    let html;
    if(rule == "mafia"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/mafia.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

    if(rule == "civilian"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/civilian.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

    if(rule == "sheriff"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/sheriff.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

    if(rule == "doctor"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/doctor.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

    if(rule == "mistress"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/mistress.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

    if(rule == "maniac"){
        html = `<div class="floating-image" id="floatingImage">
                <img src = "data/maniac.jpg">
            </div>`;
        game.innerHTML += html;
        showImage();
    }

}
